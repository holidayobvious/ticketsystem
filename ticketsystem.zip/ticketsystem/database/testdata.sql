-- Vis info i tabellene
SELECT * FROM kunde;
SELECT * FROM henvendelse;

-- Legg til data i kunde tabellen
INSERT INTO kunde (fornavn, etternavn, email, beskrivelse) 
VALUES ('Jens', 'Jensen', 'jensern@kuben.no', 'Jeg får ikke kameraet mitt til å fungere. Det er svart når det skal være på');

-- Legg til data i hendvenelse tabellen
INSERT INTO henvendelse (status, kunde_id) 
VALUES ('Løst', 3);
