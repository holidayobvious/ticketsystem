<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Logg inn</title>
</head>
<body>

 <!-- Meny -->
 <div class="navbar">
        <a href="index.php">Hjem</a>
        <a href="logginn.php">Logg inn </a>
        <a href="status.php">Sjekk status</a>
    </div>
    
    <!-- Plass mellom menyen og teksten -->
    <div class="main">
        <h2> Logg inn </h2>
    </div>
    
</body>
</html>