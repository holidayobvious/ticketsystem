<?php
// Inkluder tilkoblingsfilen
include 'db.php';

// Sjekk om skjemaet er sendt inn
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sjekk om alle nødvendige felt er fylt ut
    if (isset($_POST['fornavn'], $_POST['etternavn'], $_POST['email'], $_POST['beskrivelse'])) {
        // Hent dataene fra POST-variablene og sanitizere dem
        $fornavn = htmlspecialchars($_POST['fornavn']);
        $etternavn = htmlspecialchars($_POST['etternavn']);
        $email = htmlspecialchars($_POST['email']);
        $beskrivelse = htmlspecialchars($_POST['beskrivelse']);

        // Lagre dataene i databasen med forberedt uttalelse
        $sql = "INSERT INTO kunde (fornavn, etternavn, email, beskrivelse) VALUES (?, ?, ?, ?)";
        $stmt = $tilkobling->prepare($sql);
        $stmt->bind_param("ssss", $fornavn, $etternavn, $email, $beskrivelse);

        if ($stmt->execute()) {
            echo "Takk, $fornavn. Din problemrapport har blitt mottatt!";
        } else {
            echo "Feil: Problem med å legge til data i databasen.";
        }

        // Lukk forberedt uttalelse
        $stmt->close();
    } else {
        // Hvis ikke alle feltene er fylt ut, gi en feilmelding
        echo "Alle felt må fylles ut!";
    }
} else {
    // Hvis skjemaet ikke er sendt inn med POST-metoden, gi en feilmelding
    echo "Noe gikk galt. Vennligst prøv igjen senere.";
}

// Lukk tilkoblingen til databasen
$tilkobling->close();

// Knapp for å komme tilbake til start siden/ legge til meny + style
// Gi saksnummer
?>
