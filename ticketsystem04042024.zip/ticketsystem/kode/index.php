<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Ticketsystem</title>
</head>

<body>

    <!-- Meny -->
    <div class="navbar">
        <a href="index.php">Hjem</a>
        <a href="logginn.php">Logg inn </a>
        <a href="status.php">Sjekk status</a>
    </div>

    <!-- Plass mellom menyen og teksten -->
    <div class="main">
        <h2> Velkommen til Fjell Bedriftsløsninger! </h2>
        <h4> Her kan du legge inn et problem som du har når det kommer til IT. </h4>

        <!-- Legge til problemskjema-->
        <h2>Rapporter et problem</h2>
        <form method="post" action="handle_problem.php">
            Fornavn: <input type="text" name="fornavn"><br><br>
            Etternavn: <input type="text" name="etternavn"><br><br>
            E-post: <input type="text" name="email"><br><br>
            Beskrivelse av problem: <br><textarea name="beskrivelse" rows="5" cols="40"></textarea><br><br>
            <input type="submit" name="submit" value="Send inn">
        </form>
    </div>

</body>

</html>